package ca.concordia.soen6841.employee.pojo;

public class Salary {
    private Long salary;
    private Long bonus;

    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    public Long getBonus() {
        return bonus;
    }

    public void setBonus(Long bonus) {
        this.bonus = bonus;
    }
}
