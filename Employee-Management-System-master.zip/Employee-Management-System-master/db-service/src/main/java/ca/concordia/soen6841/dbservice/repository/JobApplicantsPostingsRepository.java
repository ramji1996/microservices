/*package ca.concordia.soen6841.dbservice.repository;

import ca.concordia.soen6841.dbservice.model.JobApplicantsPostings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JobApplicantsPostingsRepository extends JpaRepository<JobApplicantsPostings, Integer>, JobApplicantsPostingsCustomRepository {

}
*/