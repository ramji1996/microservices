package ca.concordia.soen6841.auth.model;

public enum RoleName {

	ROLE_EMPLOYEE, ROLE_ADMIN
}
