package ca.concordia.soen6841.job.pojo;

public enum ApplicantStatus {
    OPEN, CLOSED
}
