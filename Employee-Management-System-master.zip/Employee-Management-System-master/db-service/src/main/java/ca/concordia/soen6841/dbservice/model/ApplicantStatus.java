package ca.concordia.soen6841.dbservice.model;

public enum  ApplicantStatus {
    OPEN, CLOSED
}
